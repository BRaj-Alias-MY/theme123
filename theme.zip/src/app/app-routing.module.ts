import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main/main.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Dashboard2Component } from './dashboard2/dashboard2.component';
import { LoginComponent } from './login/login.component';



// const routes: Routes = [
//   { path: 'login', component: LoginComponent },
//   { path: 'home', component: MainDashboardComponent, canActivate: [AuthGuard]  },
//   { path: 'cdm', component: CreateCdmComponent, canActivate: [AuthGuard] },
//   { path: 'user', component: CreateUserComponent, canActivate: [AuthGuard]  },
//   { path: 'error', component: ErrorComponent },
//   { path: 'change-password', component: ChangePasswordComponent, canActivate: [AuthGuard]  },
//   {
//     path: '',
//     redirectTo: 'login',
//     pathMatch: 'full'
//   },
//   {
//     path: '**',
//     component: ErrorNotFoundComponent
// }
// ];

const routes: Routes = [

  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  {
    path: 'main', component: MainComponent, children: [
      { path: 'main', component: MainComponent, outlet: 'home' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'dashboard2', component: Dashboard2Component },
    ]
  }
];

@NgModule({
 imports: [ RouterModule.forRoot(routes) ],
 exports: [ RouterModule ]
})
export class AppRoutingModule {}
