import { Component, OnInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
     $.getScript('assets/plugin/chart/morris/morris.min.js');
    $.getScript('assets/plugin/chart/morris/raphael-min.js');
    $.getScript('assets/scripts/chart.morris.init.min.js');

  }

}
